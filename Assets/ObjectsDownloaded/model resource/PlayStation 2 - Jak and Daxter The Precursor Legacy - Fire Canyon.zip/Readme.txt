Reflective objects use the following environment maps:

Eco Vent Valve - pal-environment-front
Everything else - fcn-envmap